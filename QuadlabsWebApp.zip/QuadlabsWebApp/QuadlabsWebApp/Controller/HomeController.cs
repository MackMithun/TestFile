﻿using Microsoft.AspNetCore.Mvc;
using QuadlabsWebApp.Models;
using QuadlabsWebApp.Service;

namespace QuadlabsWebApp.Controller1
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            try
            {
                databaeConnection database = new databaeConnection();
                List<TBLEmployeeModel> employeeModels = database.fnGetEmployee();
                ViewBag.Employees = employeeModels; 
                return View();
            }
            catch(Exception ex)
            {
                return View();
            }
            
        }
        public IActionResult EmployeeIndex()
        {
            try
            {
                databaeConnection database = new databaeConnection();
                List<TBLDepartmentModel> employeeModels = database.fnGetDepartment();
                ViewBag.Department = employeeModels;
                List<ReportingToModel> reportingToModels = database.fnGetReportingTo(1);
                ViewBag.Reporting = reportingToModels;
                return View();
            }
            catch(Exception ex) {
                return View();
            }   
        }
        [HttpPost]
        public IActionResult EmployeeIndex(TBLEmployeeModel employeeModel)
        {
            bool status=false;
            try
            {
                databaeConnection database = new databaeConnection();
                status=database.fnInsertData(employeeModel);
                return Json(status);
            }
            catch (Exception ex)
            {
                return View(status);
            }
        }
        [HttpPost]
        public IActionResult getReportingToName(int id)
        {
            try
            {
                databaeConnection database = new databaeConnection();
                List<ReportingToModel> employeeModels = database.fnGetReportingTo(id);
                return Json(employeeModels);
            }
            catch (Exception ex)
            {
                return View();
            }
        }
        public IActionResult GetEmployeeById(int employeeId)
        {
            TBLEmployeeModel employeeModels =null;
            try
            {
                databaeConnection database = new databaeConnection();
                employeeModels  = database.fnGetEmployeeByID(employeeId);
                ViewBag.Departments = database.fnGetDepartment();
                int reportingID= database.fnGetReportingToID(employeeModels.ReportingtoName);
                ViewBag.ReportingToNames = database.fnGetReportingTo(reportingID);
                return View(employeeModels);
            }
            catch (Exception ex)
            {
                return View();
            }
        }
        [HttpPost]
        public IActionResult GetEmployeeById(TBLEmployeeModel employeeModel)
        {
            bool status = false;
            try
            {
                databaeConnection database = new databaeConnection();
                status = database.UpdateEmployeeByEmail(employeeModel.Email, employeeModel);
                return Json(new { success = status });
            }
            catch (Exception ex)
            {
                return View(status);
            }
        }
        [HttpPost]
        public IActionResult Delete(int employeeId)
        {
            bool success = false;
            try
            {
                databaeConnection database = new databaeConnection();
                success = database.DeleteEmployeeById(employeeId);

                return Json(new { success });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message });
            }
        }
    }
}
