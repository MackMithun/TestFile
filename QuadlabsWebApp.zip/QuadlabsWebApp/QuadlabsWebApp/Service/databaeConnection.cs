﻿using QuadlabsWebApp.Models;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.PortableExecutable;

namespace QuadlabsWebApp.Service
{
    public class databaeConnection
    {
        public string ConnectionString { get; set; }
        public databaeConnection()
        {
            ConnectionString = "server=UC-LT-84\\SQLEXPRESS01;Database=TestMithun;Encrypt=False;Integrated Security=True";
        }
        public bool fnInsertData(TBLEmployeeModel tBLEmployee)
        {
            bool Status = false;
            try
            {
                using (SqlConnection cn = new SqlConnection(ConnectionString))
                {
                    cn.Open();
                    using (SqlCommand cmd = new SqlCommand("Sp_InsertData", cn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Name", tBLEmployee.Name);
                        cmd.Parameters.AddWithValue("@LastName", tBLEmployee.LastName);
                        cmd.Parameters.AddWithValue("@Email", tBLEmployee.Email);
                        cmd.Parameters.AddWithValue("@Gender", tBLEmployee.Gender);
                        cmd.Parameters.AddWithValue("@ContactNo", tBLEmployee.ContactNo);
                        cmd.Parameters.AddWithValue("@DepartmentName", tBLEmployee.DepartmentName);
                        cmd.Parameters.AddWithValue("@ReportingtoName", tBLEmployee.ReportingtoName);
                        cmd.Parameters.AddWithValue("@Status", tBLEmployee.Status);

                        cmd.ExecuteNonQuery();
                    }
                }

                Status = true;
            }
            catch (Exception ex)
            {
                return Status;
            }

            return Status;
        }
        public List<TBLDepartmentModel> fnGetDepartment()
        {
            string query = "SELECT * FROM TBLDepartment";
            List<TBLDepartmentModel> departmentList = new List<TBLDepartmentModel>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                TBLDepartmentModel tBLDepartmentModel = new TBLDepartmentModel
                                {
                                    departmentId = reader.GetInt32(reader.GetOrdinal("DepartmentID")),
                                    departmentName = reader.GetString(reader.GetOrdinal("DepartmentName"))
                                };
                                departmentList.Add(tBLDepartmentModel);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                }
            }

            return departmentList;
        }
        public int fnGetReportingToID(string Name)
        {
            string query = "SELECT * FROM ReportingTo WHERE ReportingName = @Name";
            int reportingID = 0;

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@Name", Name);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                reportingID = reader.GetInt32(reader.GetOrdinal("DepartID"));
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
            return reportingID;
        }
        public List<ReportingToModel> fnGetReportingTo(int ID)
        {
            string query = "SELECT * FROM ReportingTo WHERE DepartID = @ID";
            List<ReportingToModel> reportingToModel = new List<ReportingToModel>();

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        command.Parameters.AddWithValue("@ID", ID);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ReportingToModel reportingToModel1 = new ReportingToModel
                                {
                                    DepartID = reader.GetInt32(reader.GetOrdinal("DepartID")),
                                    ReportingName = reader.GetString(reader.GetOrdinal("ReportingName"))
                                };

                                reportingToModel.Add(reportingToModel1);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }

            return reportingToModel;
        }

        public List<TBLEmployeeModel> fnGetEmployee()
        {
            string query = "SELECT * FROM TBLEmployee";
            List<TBLEmployeeModel> employeeModel = new List<TBLEmployeeModel>();
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    TBLEmployeeModel tBLEmployeeModel = new TBLEmployeeModel
                                    {							
                                        Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                        Name= reader.GetString(reader.GetOrdinal("Name")),
                                        LastName= reader.GetString(reader.GetOrdinal("LastName")),
                                        Email= reader.GetString(reader.GetOrdinal("Email")),
                                        Gender= reader.GetString(reader.GetOrdinal("Gender")),
                                        ContactNo= reader.GetString(reader.GetOrdinal("ContactNo")),
                                        DepartmentName= reader.GetString(reader.GetOrdinal("DepartmentName")),
                                        ReportingtoName= reader.GetString(reader.GetOrdinal("ReportingtoName")),
                                        Status= reader.GetBoolean(reader.GetOrdinal("Status"))
                                    };
                                    employeeModel.Add(tBLEmployeeModel);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
            return employeeModel;
        }
        public TBLEmployeeModel fnGetEmployeeByID(int id)
        {
            TBLEmployeeModel employeeModels = null;   
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand("sp_GetData", connection))
                {
                    try
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    employeeModels = new TBLEmployeeModel
                                    {
                                        Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                        Name = reader.GetString(reader.GetOrdinal("Name")),
                                        LastName = reader.GetString(reader.GetOrdinal("LastName")),
                                        Email = reader.GetString(reader.GetOrdinal("Email")),
                                        Gender = reader.GetString(reader.GetOrdinal("Gender")),
                                        ContactNo = reader.GetString(reader.GetOrdinal("ContactNo")),
                                        DepartmentName = reader.GetString(reader.GetOrdinal("DepartmentName")),
                                        ReportingtoName = reader.GetString(reader.GetOrdinal("ReportingtoName")),
                                        Status = reader.GetBoolean(reader.GetOrdinal("Status"))
                                    };
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                    return employeeModels;
                }
            }
        }
        public bool UpdateEmployeeByEmail(string email, TBLEmployeeModel updatedEmployee)
        {
            string query = "UPDATE TBLEmployee SET Name = @Name, LastName = @LastName, Gender = @Gender, " +
                           "DepartmentName = @DepartmentName, ReportingtoName = @ReportingtoName, " +
                           "ContactNo = @ContactNo, Status = @Status " +
                           "WHERE Email = @Email";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Name", updatedEmployee.Name);
                    command.Parameters.AddWithValue("@LastName", updatedEmployee.LastName);
                    command.Parameters.AddWithValue("@Gender", updatedEmployee.Gender);
                    command.Parameters.AddWithValue("@DepartmentName", updatedEmployee.DepartmentName);
                    command.Parameters.AddWithValue("@ReportingtoName", updatedEmployee.ReportingtoName);
                    command.Parameters.AddWithValue("@ContactNo", updatedEmployee.ContactNo);
                    command.Parameters.AddWithValue("@Status", updatedEmployee.Status);
                    command.Parameters.AddWithValue("@Email", email);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                    catch (Exception ex)
                    {
                        return false;
                    }
                }
            }
        }
        public bool DeleteEmployeeById(int id)
        {
            string query = "DELETE FROM TBLEmployee WHERE Id = @Id";

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                    catch (Exception ex)
                    {
                        return false;
                    }
                }
            }
        }
    }
}
