﻿namespace QuadlabsWebApp.Models
{
    public class TBLDepartmentModel
    {
        public int departmentId { get; set; }
        public string departmentName { get; set; }
    }
}
