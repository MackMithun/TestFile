﻿namespace QuadlabsWebApp.Models
{
    public class TBLEmployeeModel
    {
        public int Id { get; set; } 
        public string? Name { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? Gender { get; set; }
        public string? ContactNo { get; set; }
        public string? DepartmentName { get; set; }
        public string? ReportingtoName { get; set; }
        public bool Status { get; set; }
    }
}
