﻿namespace QuadlabsWebApp.Models
{
    public class ReportingToModel
    {
        public int DepartID { get; set; }
        public string? ReportingName { get; set; }
    }
}
